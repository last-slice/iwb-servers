
import { initIWBScene } from "./iwb/iwb"

export function main() {
  initIWBScene()
}
