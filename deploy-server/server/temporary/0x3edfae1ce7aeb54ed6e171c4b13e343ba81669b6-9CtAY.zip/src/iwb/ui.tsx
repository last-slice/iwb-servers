
import {
    engine,
    Transform,
    UiCanvasInformation,
    } from '@dcl/sdk/ecs'
    import { Color4 } from '@dcl/sdk/math'
    import ReactEcs, { Button, Label, ReactEcsRenderer, UiEntity } from '@dcl/sdk/react-ecs'
    import { uiSizer } from './helpers'
    import { createDialogPanel } from './dialogPanel'

export function setupUi() {
    ReactEcsRenderer.setUiRenderer(uiComponent)
    engine.addSystem(uiSizer)
    }
    
    const uiComponent = () => [
    createShowTextComponent(),
    createDialogPanel(),
    ]
