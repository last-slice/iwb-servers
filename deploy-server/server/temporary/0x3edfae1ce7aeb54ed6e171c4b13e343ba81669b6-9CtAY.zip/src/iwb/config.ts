
export let scene:any = {
  "id": "9CtAY",
  "n": "tes2",
  "d": "test2",
  "o": "0x3edfae1ce7aeb54ed6e171c4b13e343ba81669b6",
  "ona": "BuilderWorld",
  "cat": "",
  "bpcl": "0,3",
  "w": "BuilderWorld.dcl.eth",
  "im": "",
  "bps": [
    "0xaabe0ecfaf9e028d63cf7ea7e772cf52d662691a"
  ],
  "pcls": [
    "0,3"
  ],
  "sp": [
    "9,1,7"
  ],
  "cp": [
    "14,0,8"
  ],
  "cd": 1710899053,
  "upd": 1710899053,
  "si": 45572,
  "toc": 0,
  "pc": 332,
  "pcnt": 1,
  "isdl": false,
  "e": true,
  "priv": false,
  "lim": true,
  "ass": [
    {
      "id": "fc7cfc62-c497-4d10-aad4-b61975e603a0",
      "aid": "lwd9yY",
      "n": "AcousticPanelWall",
      "type": "3D",
      "sty": "Local",
      "editing": false,
      "ugc": false,
      "pending": false,
      "editor": "",
      "buildVis": true,
      "locked": false,
      "p": {
        "x": 7.77,
        "y": 0,
        "z": 9.2
      },
      "r": {
        "x": 0,
        "y": 354.17,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Trigger",
        "Action",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 0,
        "iMask": 3
      },
      "trigComp": {
        "enabled": false,
        "triggers": []
      },
      "actComp": {
        "actions": {}
      }
    }
  ]
};
