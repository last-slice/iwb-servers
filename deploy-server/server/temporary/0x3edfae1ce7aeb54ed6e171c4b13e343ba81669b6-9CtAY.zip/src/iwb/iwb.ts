
import { Entity, GltfContainer, Material, MeshCollider, MeshRenderer, Transform, VideoPlayer, engine } from "@dcl/sdk/ecs"
import { Color4, Quaternion, Vector3 } from "@dcl/sdk/math"
import { scene } from "./config"
import * as IWB from './components'
import { enableSceneEntities } from './playMode'

export let sceneParent:Entity
export let iwbAssets:any[] = []

export let itemIdsFromEntities: Map<number, any> = new Map()
export let entitiesFromItemIds: Map<string, Entity> = new Map()

export async function initIWBScene(){
    await createParent()
    await createSceneItems()
    enableSceneEntities(scene)
}

async function createParent(){
    sceneParent = engine.addEntity()
     const [x1, y1] = scene.bpcl.split(",")
     let x = parseInt(x1)
     let y = parseInt(y1)
 
     Transform.create(sceneParent)
}

async function createSceneItems(){
    scene.entities = []
    
    scene.ass.forEach((item:any)=>{
        let entity = engine.addEntity()
        Transform.create(entity, {parent:sceneParent, position:item.p, rotation:Quaternion.fromEulerDegrees(item.r.x, item.r.y, item.r.z), scale:item.s})
        addAssetComponents(entity, item, item.type, item.n)
    })
}

async function addAssetComponents(entity:Entity, item:any, type:string, name:string){

    IWB.createVisiblityComponent(entity, item)

    switch(type){

    case '3D':
        IWB.createGltfComponent(entity, item)
        break;

    case '2D':
        if(item.colComp.vMask === 1){
            MeshCollider.setPlane(entity)
        }
        
        switch(name){
            case 'Image':
                MeshRenderer.setPlane(entity)
                IWB.updateImageUrl(entity, item)
                break;

            case 'Video':
                MeshRenderer.setPlane(entity)
                IWB.createVideoComponent(entity, item)
                break;

            case 'NFT Frame':
                IWB.updateNFTFrame(entity, item)
                break;

                case 'Text':
                IWB.updateTextComponent(entity, item)
                break;
                
            case 'Plane':
                MeshRenderer.setPlane(entity)
                // updateMaterialComponent(item.aid, item.matComp)
                break;
        }
        break;

    case 'Audio':
        IWB.updateAudioComponent(entity, item)
        break;

    }
    iwbAssets.push({entity:entity, data:item})
    scene.entities.push(entity)

    itemIdsFromEntities.set(entity, item.aid)
    entitiesFromItemIds.set(item.aid, entity)
}