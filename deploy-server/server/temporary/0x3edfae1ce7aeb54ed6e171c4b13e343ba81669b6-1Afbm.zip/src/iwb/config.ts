
export let scene:any = {
  "id": "1Afbm",
  "n": "New Scene 2",
  "d": "New Scene",
  "o": "0x3edfae1ce7aeb54ed6e171c4b13e343ba81669b6",
  "ona": "IWB#69b6",
  "cat": "",
  "bpcl": "1,2",
  "w": "BuilderWorld.dcl.eth",
  "im": "",
  "bps": [
    "0x87b895f37a93e76cf1c27ed68b38d77fee0f7867",
    "0x2c7c6e83ae6b0b37d64f3568df668d880dc58a73",
    "0x515bee382ea1043b699863c06f319a8267d58431",
    "0x3863c8199b660f6bb1e0b9b40c58edce5999b17f",
    "0xd2cb190b90274d697f5f42bad7e3f47844d411af",
    "0x09bc69a986e1b37fb01ef36124f4c2e14fa0ab6b"
  ],
  "pcls": [
    "1,2",
    "0,2",
    "0,3",
    "1,3"
  ],
  "sp": [
    "0,0"
  ],
  "ass": [
    {
      "id": "1ed7a09d-e886-42ea-9e66-7079b88894fc",
      "aid": "M2KJbv",
      "type": "3D",
      "editing": false,
      "p": {
        "x": -15.49,
        "y": 0.23,
        "z": 31.63
      },
      "r": {
        "x": 0,
        "y": 277.35,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "1ed7a09d-e886-42ea-9e66-7079b88894fc",
      "aid": "JdP0wT",
      "type": "3D",
      "editing": false,
      "p": {
        "x": -10.87,
        "y": 0.39,
        "z": 30.66
      },
      "r": {
        "x": 0,
        "y": 4.25,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "ce42d438-1857-445d-98e6-de63fa397d85",
      "aid": "p4TSKT",
      "type": "3D",
      "editing": false,
      "p": {
        "x": -3.78,
        "y": 0.07,
        "z": 24.81
      },
      "r": {
        "x": 0,
        "y": 279.9,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "940eae2c-ce7d-4d09-ac71-c9e3f488270e",
      "aid": "n1Ertz",
      "type": "3D",
      "editing": false,
      "p": {
        "x": -12.28,
        "y": -0.12,
        "z": 21.79
      },
      "r": {
        "x": 0,
        "y": 279.45,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "940eae2c-ce7d-4d09-ac71-c9e3f488270e",
      "aid": "OgQ7Wy",
      "type": "3D",
      "editing": false,
      "p": {
        "x": -12.79,
        "y": 0.21,
        "z": 20.74
      },
      "r": {
        "x": 0,
        "y": 233.8,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "940eae2c-ce7d-4d09-ac71-c9e3f488270e",
      "aid": "3DGyes",
      "type": "3D",
      "editing": false,
      "p": {
        "x": -13.65,
        "y": 0.25,
        "z": 20.78
      },
      "r": {
        "x": 0,
        "y": 247.72,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "40b5c11b-1f16-43b5-9984-4dc21558908a",
      "aid": "FpIfxG",
      "type": "3D",
      "editing": false,
      "p": {
        "x": -6.46,
        "y": -0.08,
        "z": 28.15
      },
      "r": {
        "x": 0,
        "y": 316.25,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "940eae2c-ce7d-4d09-ac71-c9e3f488270e",
      "aid": "tl7arW",
      "type": "3D",
      "editing": false,
      "p": {
        "x": -15.14,
        "y": 0.01,
        "z": 21.16
      },
      "r": {
        "x": 0,
        "y": 266.05,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "42c98147-10fd-4ad7-a875-6df5f14b5c86",
      "aid": "NaY9va",
      "type": "3D",
      "editing": false,
      "p": {
        "x": -10.51,
        "y": 1.14,
        "z": 27.44
      },
      "r": {
        "x": 0,
        "y": 292.78,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "b50ce498-a294-4c45-ac06-ecd863882f02",
      "aid": "jjKpLf",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 0.22,
        "y": 0.04,
        "z": 24.12
      },
      "r": {
        "x": 0,
        "y": 210.44,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "ce42d438-1857-445d-98e6-de63fa397d85",
      "aid": "1vpzbe",
      "type": "3D",
      "editing": false,
      "p": {
        "x": -6.3,
        "y": 0.05,
        "z": 30.65
      },
      "r": {
        "x": 0,
        "y": 28.68,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "940eae2c-ce7d-4d09-ac71-c9e3f488270e",
      "aid": "orrX93",
      "type": "3D",
      "editing": false,
      "p": {
        "x": -10.65,
        "y": 0.07,
        "z": 24.48
      },
      "r": {
        "x": 0,
        "y": 97.23,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "88ed0e26-f67f-4883-ac47-904fb69f1357",
      "aid": "ZVNRZ2",
      "type": "3D",
      "editing": false,
      "p": {
        "x": -5.49,
        "y": 0.38,
        "z": 24.38
      },
      "r": {
        "x": 0,
        "y": 148.31,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "7b9d3700-f0fc-4b4c-8455-2307e8d13416",
      "aid": "d8QBzO",
      "type": "3D",
      "editing": false,
      "p": {
        "x": -13.64,
        "y": -0.22,
        "z": 22.65
      },
      "r": {
        "x": 0,
        "y": 154.96,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "46065d23-0dab-45a7-8a32-96834838c6ca",
      "aid": "1sK96H",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 13.17,
        "y": 0.14,
        "z": 27.71
      },
      "r": {
        "x": 0,
        "y": 179.58,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "543f177e-3fe9-41a4-8edc-66a3817590cf",
      "aid": "UH2TBI",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 14.19,
        "y": -1.05,
        "z": 29.3
      },
      "r": {
        "x": 0,
        "y": 357.83,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "543f177e-3fe9-41a4-8edc-66a3817590cf",
      "aid": "ID3EcS",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 15.67,
        "y": -0.36,
        "z": 29.41
      },
      "r": {
        "x": 0,
        "y": 359.89,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "543f177e-3fe9-41a4-8edc-66a3817590cf",
      "aid": "GxgGS5",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 12.38,
        "y": -0.11,
        "z": 27.17
      },
      "r": {
        "x": 0,
        "y": 90.5,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "845dd285-785e-4384-b5af-38161a46797f",
      "aid": "h6SjKM",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 12.47,
        "y": -0.06,
        "z": 25.18
      },
      "r": {
        "x": 0,
        "y": 90.2,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "7b9d3700-f0fc-4b4c-8455-2307e8d13416",
      "aid": "dawoRY",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 6.09,
        "y": 0,
        "z": 26.31
      },
      "r": {
        "x": 0,
        "y": 186.62,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "543f177e-3fe9-41a4-8edc-66a3817590cf",
      "aid": "DkRtvo",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 12.23,
        "y": 0,
        "z": 23.22
      },
      "r": {
        "x": 0,
        "y": 92.49,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "543f177e-3fe9-41a4-8edc-66a3817590cf",
      "aid": "DiQgd9",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 14.11,
        "y": -0.03,
        "z": 23.37
      },
      "r": {
        "x": 0,
        "y": 1.44,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "543f177e-3fe9-41a4-8edc-66a3817590cf",
      "aid": "I9I3zW",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 15.82,
        "y": -0.25,
        "z": 23.41
      },
      "r": {
        "x": 0,
        "y": 1.68,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "ce42d438-1857-445d-98e6-de63fa397d85",
      "aid": "K9Pndd",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 12.84,
        "y": -0.05,
        "z": 23.9
      },
      "r": {
        "x": 0,
        "y": 180.83,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "953dc6de-23d4-4db1-b346-facfa7462527",
      "aid": "4LEuLy",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 12.73,
        "y": 1.04,
        "z": 24.27
      },
      "r": {
        "x": 0,
        "y": 181.75,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "d9eba01a-51f4-4c7f-91ae-db4c5053a61f",
      "aid": "57avRv",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 13.08,
        "y": 1.09,
        "z": 23.95
      },
      "r": {
        "x": 0,
        "y": 176.68,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "65b5e15f-74be-4857-902d-7d69ac07efd5",
      "aid": "YJIvVR",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 13.45,
        "y": 1.12,
        "z": 23.94
      },
      "r": {
        "x": 0,
        "y": 171.01,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    },
    {
      "id": "e0d7a429-0188-4092-aa97-5bbae9615f86",
      "aid": "K6Dqtq",
      "type": "3D",
      "editing": false,
      "p": {
        "x": 12.59,
        "y": 1.07,
        "z": 23.9
      },
      "r": {
        "x": 0,
        "y": 184.54,
        "z": 0
      },
      "s": {
        "x": 1,
        "y": 1,
        "z": 1
      },
      "comps": [
        "Transform",
        "Visibility",
        "Collision"
      ],
      "visComp": {
        "visible": true
      },
      "colComp": {
        "vMask": 1,
        "iMask": 2
      }
    }
  ],
  "cd": 1702672455,
  "upd": 1702672455,
  "si": 7050888,
  "toc": 0,
  "pc": 33532,
  "pcnt": 4,
  "isdl": false,
  "e": true,
  "priv": false
};
